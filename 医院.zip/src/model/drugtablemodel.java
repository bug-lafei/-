package model;

import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import bean.doctor;
import bean.drug;
import bean.drug1;

public class drugtablemodel extends DefaultTableModel{
	public drugtablemodel(ArrayList<drug1> list)
	{
		String [] name= {"ҩƷ���","ҩƷ����","����","���","���ܱ��","��λ","���","����"};
		String [][] data=new String[list.size()] [name.length];
		int count=0;
	    for(int row=0;row<list.size();row++){
	    	count++;
	    	 drug1 d =(drug1)list.get(row);
	    	data[row][0]=String.valueOf(d.getDrugid());
	    	data[row][1]=d.getDrugname();
	    	data[row][2]=d.getDrugtype();
	    	data[row][3]= String.valueOf(d.getDruginventory());
	    	data[row][4]=d.getShelvesnumber();
	    	data[row][5]=d.getUnit();
	    	data[row][6]=d.getSpecifications();
	    	data[row][7]=String.valueOf(d.getUnitprice());
	    	
	   	 }
	    this.setDataVector(data, name);
	}
}
