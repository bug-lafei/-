package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.doctor;
import dao.doctordao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Adddor extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Adddor frame = new Adddor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Adddor() {
		dispose();
		setBounds(100, 100, 556, 578);
		doctordao dao=new doctordao();
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ҽ�����");
		lblNewLabel.setBounds(69, 60, 72, 18);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("����");
		label.setBounds(69, 138, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("����");
		label_1.setBounds(69, 216, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("ְ��");
		label_2.setBounds(69, 294, 72, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("��������");
		label_3.setBounds(69, 372, 72, 18);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("�������");
		label_4.setBounds(69, 450, 72, 18);
		contentPane.add(label_4);
		
		
		
		
		
		
		textField = new JTextField();
		textField.setBounds(217, 57, 164, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(217, 135, 164, 24);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(217, 213, 164, 24);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(217, 291, 164, 24);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(217, 369, 164, 24);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(217, 447, 164, 24);
		contentPane.add(textField_5);
		
		
		
		JButton btnNewButton = new JButton("����");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				doctor d=new doctor();
				d.setDornumber(Integer.valueOf(textField.getText()));
				d.setDorname(textField_1.getText());
				d.setDorroom(textField_2.getText());
				d.setDorprofess(textField_3.getText());
				d.setDortype(textField_4.getText());
				d.setDorfee(Double.parseDouble(textField_5.getText()));
				try {
					if(dao.addoctor(d))
					{
						JOptionPane.showMessageDialog(null, "���ӳɹ�");
					}
					else if(textField.getText().equals("")||textField_1.getText().equals("")||textField_2.getText().equals("")||textField_3.getText().equals("")||textField_4.getText().equals("")||textField_5.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "������Ϊ��Ŷ��");
					}
					else {
						JOptionPane.showMessageDialog(null, "����Ƿ���ظ�Ŷ");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(30, 491, 113, 27);
		contentPane.add(btnNewButton);
		
		
		JButton btnNewButton_1 = new JButton("���");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				
			}
		});
		btnNewButton_1.setBounds(311, 491, 113, 27);
		contentPane.add(btnNewButton_1);
	}

}
