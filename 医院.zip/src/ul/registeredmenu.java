package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class registeredmenu extends JFrame {

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					registeredmenu frame = new registeredmenu();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public registeredmenu(String account,String pass,String name,String id,String sex,String age) {
		dispose();
		setBounds(100, 100, 730, 554);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("����");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("��ͯ����");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenu mnNewMenu_1 = new JMenu("�ڿ�");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("�ڿ�");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem_1.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		JMenu menu = new JMenu("���");
		menuBar.add(menu);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("�����");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem_2.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		menu.add(mntmNewMenuItem_2);
		JMenu mnNewMenu_2 = new JMenu("������");
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("������");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem_3.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_3 = new JMenu("�ǿ�");
		menuBar.add(mnNewMenu_3);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("�ǿ�");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem_4.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_4);
		
		JMenu mnNewMenu_4 = new JMenu("��ٿ�");
		menuBar.add(mnNewMenu_4);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("��ٿ�");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem_5.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_5);
		
		JMenu mnNewMenu_5 = new JMenu("Ƥ����");
		menuBar.add(mnNewMenu_5);
		
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("Ƥ����");
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem_6.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		mnNewMenu_5.add(mntmNewMenuItem_6);
		
		JMenu mnNewMenu_6 = new JMenu("��ҽ��");
		menuBar.add(mnNewMenu_6);
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("��ҽ��");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				everydoctor l;
				try {
					l = new everydoctor(account,pass,mntmNewMenuItem_7.getText(),name,id,sex,age);
					l.setVisible(true);
				} catch (SQLException e1){
					e1.printStackTrace();
				}				
			}
		});
		mnNewMenu_6.add(mntmNewMenuItem_7);
	}
}
