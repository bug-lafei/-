package bean;


public class patient {//���ߵ�¼��Ϣ
	String patientid;
	String painentpass;
	String name;
	String num;
	String sex;
	String age;
	public String getPatientid() {
		return patientid;
	}
	public void setPatientid(String patientid) {
		this.patientid = patientid;
	}
	public String getPainentpass() {
		return painentpass;
	}
	public void setPainentpass(String painentpass) {
		this.painentpass = painentpass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
}
