package ul;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.cashierDao;
import dao.doctorpass;
import dao.patientDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import imges.background;
public class loginframe extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JRadioButton raddoctor;
	private JRadioButton radpatient;
	private JRadioButton radcashier;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginframe frame = new loginframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginframe() {
		dispose();
		setBounds(100, 100, 803, 609);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	
		
		JLabel label = new JLabel("\u8D26\u53F7:");
		label.setFont(new Font("����", Font.PLAIN, 24));
		label.setBounds(143, 103, 72, 37);
		contentPane.add(label);
		
		
		JLabel label_1 = new JLabel("\u5BC6\u7801:");
		label_1.setFont(new Font("����", Font.PLAIN, 24));
		label_1.setBounds(143, 204, 72, 55);
		contentPane.add(label_1);
		
		
		textField = new JTextField();
		textField.setBounds(207, 103, 203, 34);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(207, 216, 203, 37);
		contentPane.add(passwordField);
		
		
		ButtonGroup buttgroup= new ButtonGroup();
		
		JRadioButton radadmin = new JRadioButton("\u7BA1\u7406\u5458");
		radadmin.setBounds(58, 373, 98, 27);
		contentPane.add(radadmin);
		
		raddoctor = new JRadioButton("\u533B\u751F");
		raddoctor.setBounds(253, 373, 84, 27);
		contentPane.add(raddoctor);
		
		
		radpatient = new JRadioButton("\u60A3\u8005");
		radpatient.setBounds(446, 373, 84, 27);
		contentPane.add(radpatient);
		
		
		radcashier = new JRadioButton("\u6536\u8425\u5458");
		radcashier.setBounds(618, 373, 91, 27);
		contentPane.add(radcashier);
		
		
		buttgroup.add(radadmin);
		buttgroup.add(raddoctor);
		buttgroup.add(radpatient);
		buttgroup.add(radcashier);
		
		JButton button = new JButton("\u767B\u5F55");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					login();
				} catch (HeadlessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			private void login() throws HeadlessException, ClassNotFoundException, SQLException {
				// TODO Auto-generated method stub
				
				String name =textField.getText();
				String pass=String.valueOf(passwordField.getPassword());
				if(radadmin.isSelected()) {
					if(name.equals("admin")&&pass.equals("admin")) {
						JOptionPane.showMessageDialog(null, "����Ա��¼�ɹ�");
					}else {
						JOptionPane.showMessageDialog(null, "����Ա��½ʧ��");
						}
				}if(raddoctor.isSelected()) {
						doctorpass docdao =new doctorpass();
						if(docdao.login(name,pass)) {
							JOptionPane.showMessageDialog(null, "ҽ����½�ɹ�");
							doctormenu dmenu=new doctormenu(name);
							dmenu.setVisible(true);
						}else {
							JOptionPane.showMessageDialog(null, "ҽ����½ʧ��");
						}
					}else if(radpatient.isSelected()) {
						patientDao patdao=new patientDao();
						if(patdao.login(name, pass)) {
							JOptionPane.showMessageDialog(null, "�û���½�ɹ�");
							usermenu u=new usermenu(name);
							u.setVisible(true);
						}else {
							JOptionPane.showMessageDialog(null, "�û���½ʧ��");
						}
					}if(radcashier.isSelected()) {
						cashierDao casdao =new cashierDao();
						if(casdao.login(name, pass)) {
							JOptionPane.showMessageDialog(null, "����Ա��½�ɹ�");
							
						}else {
							JOptionPane.showMessageDialog(null, "����Ա��½ʧ��");
						}
					}
			}
		});
		button.setBounds(179, 465, 296, 27);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.setBounds(526, 378, 113, 27);
		
		
		textField = new JTextField();
		textField.setBounds(354, 87, 188, 32);
		
		textField.setColumns(10);
	}
}
