package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import bean.doctor;

public class doctordao {
	PreparedStatement pstmt;
	Connection conn=new jdbc.JDBC().getconection();
	ResultSet rs;
	public ArrayList<doctor> showlist() throws SQLException
	{
		ArrayList<doctor> list=new ArrayList<>();
		String sql="select * from ҽ�� ";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			doctor d=new doctor();
			d.setDornumber(rs.getInt(1));
			d.setDorname(rs.getString(2));
			d.setDorprofess(rs.getString(3));
			d.setDorroom(rs.getString(4));
			d.setDortype(rs.getString(5));
			d.setDorfee(Double.parseDouble(rs.getString(6)));
			list.add(d);
		}
		return list;
	}
	public ArrayList<doctor> Nshowlist(String name) throws SQLException
	{
		ArrayList<doctor> list=new ArrayList<>();
		String sql="select * from ҽ�� where ����=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, name);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			doctor d=new doctor();
			d.setDornumber(rs.getInt(1));
			d.setDorname(rs.getString(2));
			d.setDorprofess(rs.getString(3));
			d.setDorroom(rs.getString(4));
			d.setDortype(rs.getString(5));
			d.setDorfee(Double.parseDouble(rs.getString(6)));
			list.add(d);
		}
		return list;
	}
	public boolean addoctor(doctor d) throws SQLException
	{
		boolean flag=true;
		String sql="insert into ҽ�� values(?,?,?,?,?,?)";
		pstmt=conn.prepareStatement(sql);
		int i=0;
		pstmt.setInt(1, d.getDornumber());
		pstmt.setString(2, d.getDorname());
		pstmt.setString(3, d.getDorprofess());
		pstmt.setString(4, d.getDortype());
		pstmt.setString(5, d.getDortype());
		pstmt.setString(6,String.valueOf(d.getDorfee()));
		i=pstmt.executeUpdate();
		if(i>0)
		{
			flag=true;
		}
		else {
			flag=false;
		}
		return flag;
	}
	public  boolean deletecourse(String id)
	{
		int i=0;
		String sql="delete from ҽ�� where ҽ�����=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, id);
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(i>0)
		{
			return true;
		}
		else {
			return false;
		}
		
	}
	public boolean modify(doctor d) throws SQLException
	{
		int i=0;
		boolean flag=true;
		String sql="update ҽ�� set ҽ������=?,ְ��=?,����=?,��������=?,�������=? where ҽ�����=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,d.getDorname());
		pstmt.setString(2,d.getDorprofess());
		pstmt.setString(3,d.getDorroom());
		pstmt.setString(4,d.getDortype());
		pstmt.setString(5,String.valueOf(d.getDorfee()));
		pstmt.setInt(6,d.getDornumber());
		i=pstmt.executeUpdate();
		if(i>0)
		{
			flag=true;
		}
		else{
			flag=false;
		}
		return flag;
	}
	public ArrayList<doctor> numshowlist(String name) throws SQLException
	{
		ArrayList<doctor> list=new ArrayList<>();
		String sql="select * from ҽ�� where ҽ�����=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, name);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			doctor d=new doctor();
			d.setDornumber(rs.getInt(1));
			d.setDorname(rs.getString(2));
			d.setDorprofess(rs.getString(3));
			d.setDorroom(rs.getString(4));
			d.setDortype(rs.getString(5));
			d.setDorfee(Double.parseDouble(rs.getString(6)));
			list.add(d);
		}
		return list;
	}
}
