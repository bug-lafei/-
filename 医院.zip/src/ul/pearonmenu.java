package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.patient;
import dao.patientDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class pearonmenu extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					pearonmenu frame = new pearonmenu();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public pearonmenu(String id,String pass,String name,String num,String sex,String age) {
		dispose();
		setBounds(100, 100, 564, 456);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("����");
		lblNewLabel.setBounds(78, 104, 72, 18);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setText(name);
		textField.setBounds(199, 101, 132, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("����֤��");
		label.setBounds(78, 151, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("�Ա�");
		label_1.setBounds(78, 200, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("����");
		label_2.setBounds(78, 250, 72, 18);
		contentPane.add(label_2);
		
		textField_1 = new JTextField();
		textField_1.setText(num);
		textField_1.setColumns(10);
		textField_1.setBounds(199, 148, 132, 24);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setText(sex);
		textField_2.setColumns(10);
		textField_2.setBounds(199, 197, 132, 24);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setText(age);
		textField_3.setColumns(10);
		textField_3.setBounds(199, 247, 132, 24);
		contentPane.add(textField_3);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addItem(id);
		comboBox.setBounds(88, 293, 106, 24);
		contentPane.add(comboBox);
		JButton btnNewButton = new JButton("����");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patient p=new patient();
				p.setPatientid(String.valueOf(comboBox.getSelectedItem()));
				p.setPainentpass(textField_5.getText());
				p.setName(textField.getText());
				p.setNum(textField_1.getText());
				p.setSex(textField_2.getText());
				p.setAge(textField_3.getText());
				patientDao pdao=new patientDao();
				if(pdao.modifyStuInfo(p)) {
					JOptionPane.showMessageDialog(null, "����ɹ���");
				}else {
					JOptionPane.showMessageDialog(null, "�޸���������ϵ����Ա");
				}
			}
		});
		btnNewButton.setBounds(42, 343, 113, 27);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setBounds(297, 343, 113, 27);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("�˺�");
		lblNewLabel_1.setBounds(14, 296, 72, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("����");
		lblNewLabel_2.setBounds(277, 296, 72, 18);
		contentPane.add(lblNewLabel_2);
		
		textField_5 = new JTextField();
		textField_5.setText(pass);
		textField_5.setBounds(393, 293, 120, 24);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("ʵ��ע�᣺");
		lblNewLabel_3.setBounds(78, 38, 155, 37);
		contentPane.add(lblNewLabel_3);
		
		
	}
}
