package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.patient;
import bean.visitdoctor;

public class visitdoctordao {
	PreparedStatement pstmt;
	Connection conn=new jdbc.JDBC().getconection();
	ResultSet rs;
	public ArrayList<visitdoctor> showlist(String id) throws SQLException
	{
		String sql="select * from ���� where ҽ��=?";
		ArrayList<visitdoctor> list=new ArrayList<>();
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			visitdoctor v=new visitdoctor();
			v.setVistnum(rs.getString(1));
			v.setName(rs.getString(1));
			v.setSex(rs.getString(3));
			v.setAge(rs.getString(4));
			v.setMydor(String.valueOf(rs.getString(5)));
			v.setRoom(String.valueOf(rs.getString(6)));
			v.setResult(rs.getString(7));
			v.setFee(Double.parseDouble(rs.getString(8)));
			list.add(v);
		}
		return list;
	}
	public boolean modify(visitdoctor p){//ʵ���Ͼ���ҽ�������ʱ��ı������
		int i=0;
		try{
			String updatesql="update ���� set ������=?"
					+" where �����=?";						
			pstmt=conn.prepareStatement(updatesql);
			pstmt.setString(1, p.getResult());
			pstmt.setString(2,p.getVistnum());
			i=pstmt.executeUpdate();
		}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
		}
		if(i>0){
			return true;
		}
		else {
			return false;
		}
	}
}
