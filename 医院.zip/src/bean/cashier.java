package bean;


public class cashier {
	public String cashierId;
	public String getCashierId() {
		return cashierId;
	}
	public void setCashierId(String cashierId) {
		this.cashierId = cashierId;
	}
	public String getCashierpass() {
		return cashierpass;
	}
	public void setCashierpass(String cashierpass) {
		this.cashierpass = cashierpass;
	}
	public String cashierpass;
}
