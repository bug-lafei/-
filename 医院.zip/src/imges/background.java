package imges;


import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import ul.loginframe;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
public class background extends JPanel{
	Image im;
	public background() {
		im = new ImageIcon(background.class.getResource("hospital.jpg")).getImage();
		this.setOpaque(true);
	}
	@Override
	public void paintComponent(Graphics g) {
		loginframe login =new loginframe();
		super.paintComponent(g);
		g.drawImage(im,0,0,this.getWidth(),this.getHeight(),this);
	}
}