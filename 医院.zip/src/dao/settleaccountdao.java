package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.cj.protocol.Resultset;

import bean.doctor;
import bean.settleaccount;
import jdbc.JDBC;

public class settleaccountdao {
	PreparedStatement pstmt;
	ResultSet rs;
	Connection conn=new jdbc.JDBC().getconection();	
	public ArrayList<settleaccount> showall()
	{
		ArrayList<settleaccount> list=new ArrayList<>();
		String sql="select * from ���˵�";
		try {
			pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				settleaccount s=new settleaccount();
				s.setSurverynum(rs.getString(1));
				s.setName(rs.getString(2));
				
				s.setSflag(rs.getString(3));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	
	public boolean modify(settleaccount d) throws SQLException
	{
		int i=0;
		boolean flag=true;
		String sql="update ���˵� set �������=? where �����=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,d.getSflag());
		pstmt.setString(2,d.getSurverynum());
		i=pstmt.executeUpdate();
		if(i>0)
		{
			flag=true;
		}
		else{
			flag=false;
		}
		return flag;
	}
	public boolean addaccount(settleaccount d) throws SQLException
	{
		int i=0;
		boolean flag=true;
		String sql="insert into ���˵� values(?,?,?)";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1,d.getSurverynum());
		pstmt.setString(2,d.getName());
		pstmt.setString(3,d.getSflag());
		i=pstmt.executeUpdate();
		if(i>0)
		{
			flag=true;
		}
		else{
			flag=false;
		}
		return flag;
	}
}
