package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.drug;
import bean.mytablet;

public class dragDao {
	PreparedStatement pstmt;
	Connection conn=new jdbc.JDBC().getconection();
	ResultSet rs;
	public void insertdrug(drug dru) throws ClassNotFoundException, SQLException {
		String sql="inset into ҩƷ(ҩƷ���,ҩƷ���,����,���,���ܱ��,��λ,���,����)"
				+"values('"+dru.getDragid()+"',"
				+"'"+dru.getDragname()+"',"	
				+"'"+dru.getDrugtype()+"',"
				+"'"+dru.getDruginventory()+"',"
				+"'"+dru.getShelvesnumber()+"',"
				+"'"+dru.getUnit()+"',"
				+"'"+dru.getSpecifications()+"',"
				+"'"+dru.unitprice+")";
		Statement stmt =conn.createStatement();
		stmt.executeLargeUpdate(sql);
	}
	
	public boolean modifydrug(drug dru) {
		int i=0;
		String sql="UPDATE ҩƷ set ҩƷ���=?, ҩƷ���=?, ����=?,���=?,���ܱ��=?,��λ=?,���=?,����=? where ҩƷ���=?";
		try {
			PreparedStatement ps =conn.prepareStatement(sql);
			ps.setString(1, dru.getDragid());
			ps.setString(2, dru.getDragname());
			ps.setString(3, dru.getDrugtype());
			ps.setString(4, dru.getDruginventory());
			ps.setString(5, dru.getShelvesnumber());
			ps.setString(6, dru.getUnit());
			ps.setString(7, dru.getSpecifications());
			ps.setString(8, dru.getUnitprice());
		}catch(Exception e){
			e.printStackTrace();
		}if(i>0) {
			return true;
		}else {
			return false;
		}
	}
	public boolean delete(String drugid) {
		int i=0;
		String sql="delete from ҩƷ  where ҩƷ���=?";
		try {
			
			PreparedStatement ps =conn.prepareStatement(sql);
			ps.setString(1, drugid);
			i=ps.executeUpdate();
			}catch(Exception e){
				e.printStackTrace();
			}if(i>0) {
				return true;
			}else {
				return false;
			}
	}
	
	
	public ArrayList<drug>queryid(String drugid) throws ClassNotFoundException, SQLException{
		ArrayList<drug> list =new ArrayList<drug>();
		String sql="select * from ҩƷ�� where ҩƷ���=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, drugid);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			drug dru =new drug();
			dru.setDragid(rs.getString(1));
			dru.setDragname(rs.getString(2));
			dru.setDrugtype(rs.getString(3));
			dru.setDruginventory(rs.getString(4));
			dru.setShelvesnumber(rs.getString(5));
			dru.setUnit(rs.getString(6));
			dru.setSpecifications(rs.getString(7));
			dru.setUnitprice(rs.getString(8));
			list.add(dru);
			}
		return list;
		
	}
	public ArrayList<drug>allqueryid() throws ClassNotFoundException, SQLException{
		ArrayList<drug> list =new ArrayList<>();
		String sql="select * from ҩƷ��";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			drug dru =new drug();
			dru.setDragid(rs.getString(1));
			dru.setDragname(rs.getString(2));
			dru.setDrugtype(rs.getString(3));
			System.out.println(rs.getString(3));
			dru.setDruginventory("qweffq");
			dru.setShelvesnumber(rs.getString(5));
			dru.setUnit(rs.getString(6));
			dru.setSpecifications(rs.getString(7));
			dru.setUnitprice(rs.getString(8));
			list.add(dru);
			}
		return list;
	}
	public boolean mytablet1(mytablet m) throws SQLException {
		boolean falg=true;
		int i=0;
		String sql="insert into ҩƷ values(?,?,?,?,?,?,?,?,?)";
		pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, m.getDrugid());
		pstmt.setInt(2,m.getSurveynum());
		pstmt.setString(3, m.getDrugname());
		pstmt.setString(4, m.getDrugtype());
		pstmt.setInt(5, m.getDruginventory());
		pstmt.setString(6, m.getShelvesnumber());
		pstmt.setString(7, m.getUnit());
		pstmt.setString(8, m.getSpecifications());
		pstmt.setInt(9,m.getUnitprice());
		i=pstmt.executeUpdate();
		if(i>0)
		{
			falg=true;
		}
		else {
			falg=false;
		}
		return falg;
	}
	public ArrayList<mytablet> findnum(int id) throws ClassNotFoundException, SQLException{
		ArrayList<mytablet> list =new ArrayList<>();
		String sql="select * from ҩƷ where �����=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			mytablet dru =new mytablet();
			dru.setDrugid(rs.getInt(1));
			dru.setSurveynum(rs.getInt(2));
			dru.setDrugname(rs.getString(3));
			dru.setDrugtype(rs.getString(4));
			dru.setDruginventory(rs.getInt(5));
			dru.setShelvesnumber(rs.getString(6));
			dru.setUnit(rs.getString(7));
			dru.setSpecifications(rs.getString(8));
			dru.setUnitprice(rs.getInt(9));
			list.add(dru);
			}
		return list;
		
	}
}
