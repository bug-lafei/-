package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.doctorlogin;
import dao.doctorpass;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class doctormenu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					doctormenu frame = new doctormenu();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public doctormenu(String id) {
		dispose();
		setBounds(100, 100, 564, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		ImageIcon img2=new ImageIcon("imgg/����.jpg");
		JButton btnNewButton = new JButton(img2);
		btnNewButton.setBorder(null);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					visitdortable v=new visitdortable(id);
					v.setVisible(true);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(68, 154, 68, 68);
		contentPane.add(btnNewButton);
		
		ImageIcon img1=new ImageIcon("imgg/������ҳ.jpg");
		JButton button = new JButton(img1);
		button.setBorder(null);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ArrayList<doctorlogin> list=new ArrayList<>();
				doctorlogin don=new doctorlogin();
				doctorpass pdao=new doctorpass();
				try {
					list=pdao.findlist(id);
					don=list.get(0);
					doctorhome home=new doctorhome(don.getId(),don.getPass(),don.getNum());
					home.setVisible(true);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		button.setBounds(342, 154, 68, 68);
		contentPane.add(button);
		ImageIcon img3=new ImageIcon("imgg/���߾���.jpg");
		JButton button_1 = new JButton(img3);
		button_1.setBorder(null);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				server s=new server();
				s.setVisible(true);
				new Thread(s).start();
				
			}
		});
		
		button_1.setBounds(211, 154, 68, 68);
		contentPane.add(button_1);
		
		JLabel lblNewLabel = new JLabel("����");
		lblNewLabel.setBounds(68, 252, 72, 18);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("���߾���");
		label.setBounds(211, 252, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("������ҳ");
		label_1.setBounds(342, 252, 72, 18);
		contentPane.add(label_1);
	}

}
