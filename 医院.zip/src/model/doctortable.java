package model;

import java.util.List;


import javax.swing.table.DefaultTableModel;

import bean.doctor;
public class doctortable extends DefaultTableModel{
	public doctortable(List calssList){
		String[] calssNames = { "ҽ�����", "ҽ������","����","ְ��","��������","�������"};
		String[][] calssData =new String[calssList.size()][calssNames.length];
		int count=0;
	    for(int row=0;row<calssList.size();row++){
	    	count++;
	    	 doctor d =(doctor)calssList.get(row);
	    	calssData[row][0]=String.valueOf(d.getDornumber());
	    	calssData[row][1]=d.getDorname();
	    	calssData[row][2]=d.getDorprofess();
	    	calssData[row][3]=d.getDorroom();
	    	calssData[row][4]=d.getDortype();
	    	calssData[row][5]=String.valueOf(d.getDorfee());
	   	 }
	    this.setDataVector(calssData, calssNames);
	}
}
