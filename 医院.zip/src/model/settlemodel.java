package model;

import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import bean.settleaccount;

public class settlemodel extends DefaultTableModel{
	public settlemodel(ArrayList<settleaccount> list)
	{
		String [] name={
			"�����","��������","�������"
		};
		String [][] data=new String [list.size()][name.length];
		for(int row=0;row<list.size();row++)
		{
			settleaccount s=list.get(row);
			data[row][0]=s.getSurverynum();
			data[row][1]=s.getName();
			data[row][2]=s.getSflag();
		}
		this.setDataVector(data, name);
	}
}
