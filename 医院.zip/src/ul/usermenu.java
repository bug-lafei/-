package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.patient;
import dao.patientDao;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.Icon;
import javax.swing.JLabel;

public class usermenu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					usermenu frame = new usermenu();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public usermenu(String id) {
		dispose();
		setBounds(100, 100, 542, 438);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		ImageIcon img=new ImageIcon("imgg/�Һ�.jpg");
		JButton btnNewButton = new JButton(img);
		btnNewButton.setBorder(null);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patientDao pao=new patientDao();
				ArrayList<patient> list;
				try {
					list = pao.showlist(id);
					patient pp=(patient)list.get(0);
					registeredmenu r=new registeredmenu(pp.getPatientid(),pp.getPainentpass(),pp.getName(),pp.getNum(),pp.getSex(),pp.getAge());
					r.setVisible(true);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(62, 139, 68, 68);
		contentPane.add(btnNewButton);
		ImageIcon img1=new ImageIcon("imgg/������ҳ.jpg");
		
		JButton button = new JButton(img1);
		button.setBorder(null);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				patientDao pao=new patientDao();
				ArrayList<patient> list;
				try {
					list = pao.showlist(id);
					patient pp=(patient)list.get(0);
					pearonmenu p=new pearonmenu(pp.getPatientid(),pp.getPainentpass(),pp.getName(),pp.getNum(),pp.getSex(),pp.getAge());;
					p.setVisible(true);
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
				
			}
		});
		button.setBounds(206, 143, 68, 64);
		contentPane.add(button);
		ImageIcon img2=new ImageIcon("imgg/���߾���.jpg");
		JButton button_1 = new JButton(img2);
		button_1.setBorder(null);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				client c=new client();
				new Thread(c).start();
				
				
			}
		});
		button_1.setBounds(365, 143, 68, 68);
		contentPane.add(button_1);
		
		JLabel lblNewLabel = new JLabel("�Һ�");
		lblNewLabel.setBounds(62, 236, 72, 18);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("������ҳ");
		label.setBounds(202, 236, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("���߾���");
		label_1.setBounds(365, 236, 72, 18);
		contentPane.add(label_1);
	}
}
