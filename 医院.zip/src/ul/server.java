package ul;

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class server extends JFrame implements Runnable{
    DataInputStream inputFromClient;
    DataOutputStream outputToClient;
    
    private JButton jbSend = new JButton("Send");
    
    private JTextArea jta = new JTextArea();
   
    private JTextField jtf = new JTextField();
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Date d = new Date();
    String time = format.format(d);
    public server() {
    	addMouseListener(new MouseAdapter() {
    		@Override
    		public void mouseClicked(MouseEvent e) {
    		}
    	});
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(new JScrollPane(jta),BorderLayout.CENTER);
        JPanel p = new JPanel();
        p.setLayout(new BorderLayout());
        p.add(new JLabel("Message"), BorderLayout.WEST);
        p.add(jtf, BorderLayout.CENTER);
        jtf.setHorizontalAlignment(JTextField.LEFT);
        p.add(jbSend, BorderLayout.EAST);
        getContentPane().add(p, BorderLayout.SOUTH);
        jtf.addActionListener(new ButtonListener()); 
        jbSend.addActionListener(new ButtonListener()); 
        this.setTitle("ҽ��");
        this.setSize(500, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

    }
    public static void main(String[] args) {	
	server s=new server();
	s.setVisible(true);
	new Thread(s).start();
	}

    public class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
               
                String message = jtf.getText().trim();

               
                outputToClient.writeUTF(message);
                outputToClient.flush();

               
                jta.append(" " + time + '\n');
                jta.append(" MyMessage: " + message + "\n");
                jtf.setText(null);
            } catch (IOException ex) {
                System.err.println(ex);
            }
        }
    }

	@Override
	public void run() {
		
		 try {
	           
	            ServerSocket serverSocket = new ServerSocket(8011);         
	            jta.append(" ***Server started at  " + time +"***"+ '\n');
	            Socket socket = serverSocket.accept();
	            
	            inputFromClient = new DataInputStream(socket.getInputStream());
	            outputToClient = new DataOutputStream(socket.getOutputStream());
	            while (true) {
	                String message = inputFromClient.readUTF();
	                jta.append(" " + time + '\n');
	                jta.append(" Message: " + message + '\n');
	            }
		 } catch (IOException ex) {
	            jta.append(" ***�˿��ѱ�ռ��!*** " + '\n');
	        }
	}
	
}