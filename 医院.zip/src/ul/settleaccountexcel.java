package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import bean.mytablet;
import bean.settleaccount;
import dao.dragDao;
import dao.drugdaoo;
import dao.settleaccountdao;
import model.mydrugmodel;
import model.settlemodel;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class settleaccountexcel extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	String numm;
	String flage;
	String name;
	String casid;
	String toailcash;
	int a=0;
	int b=0;
	String cas;
	private JTextField textField;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					settleaccountexcel frame = new settleaccountexcel();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public settleaccountexcel(String casids) {
		cas=casids;
		drugdaoo mydao1=new drugdaoo();
		dragDao mydao=new dragDao();
		settleaccount s=new settleaccount();
		dispose();
		settlemodel tablemodel;
		settleaccountdao sdao=new settleaccountdao();
		setBounds(100, 100, 735, 663);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 326, 717, 234);
		contentPane.add(scrollPane_1);
		
		textField = new JTextField();
		textField.setBounds(285, 247, 86, 24);
		
		contentPane.add(textField);
		textField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 717, 234);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row=table.getSelectedRow();
				numm=String.valueOf(table.getValueAt(row, 0));
				flage=String.valueOf(table.getValueAt(row, 2));
				name=String.valueOf(table.getValueAt(row, 1));
				
				
				textField.setText(flage);
				mydrugmodel mytablemodel;
				System.out.print(numm);
				table_1 = new JTable();
				 ArrayList<mytablet> mylist;
				try {
					mylist = mydao.findnum(Integer.valueOf(numm));
					mytablemodel=new mydrugmodel(mylist);
					table_1.setModel(mytablemodel);
					scrollPane_1.setViewportView(table_1);
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				try {
					ArrayList<mytablet> tabletlist =mydao1.findpartdrug3(Integer.valueOf(numm));
					
					for(int i=0;i<tabletlist.size();i++)
					{
						mytablet mt=tabletlist.get(i);
						b=mt.getDruginventory()*mt.getUnitprice();
						a=b+a;
						System.out.println(a);
					}
					
				} catch (NumberFormatException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				
				
				
				
				
				
			}
		});
		ArrayList<settleaccount> list=sdao.showall();
		tablemodel=new settlemodel(list);
		table.setModel(tablemodel);
		scrollPane.setViewportView(table);
		
		
		
		
		
		
		
		JLabel lblNewLabel = new JLabel("����Ҫ��ҩƷ");
		lblNewLabel.setBounds(0, 285, 131, 28);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("�������");
		lblNewLabel_1.setBounds(183, 250, 72, 18);
		contentPane.add(lblNewLabel_1);
		
		
		
		JButton btnNewButton = new JButton("ȷ��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				s.setSurverynum(numm);
				s.setSflag("�Ѹ���");
				try {
					if(sdao.modify(s))
					{
						JOptionPane.showMessageDialog(null, "�ѱ���");
					}else if(textField.getText().equals("")){
						JOptionPane.showMessageDialog(null, "����д�������");
					}
					else {
						JOptionPane.showMessageDialog(null, "����ʧ�ܣ��ò����Ѿ�����");
					}
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(406, 247, 113, 27);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("������ӡ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				XSSFWorkbook book =new XSSFWorkbook();
				XSSFSheet sheet =book.createSheet("ҽԺ����");	 
				XSSFRow row=sheet.createRow(0);
				row.createCell(0).setCellValue("�����");
				row.createCell(1).setCellValue(numm);
				row.createCell(2).setCellValue("����");
				row.createCell(3).setCellValue(name);
				XSSFRow row1=sheet.createRow(1);
				row1.createCell(0).setCellValue("���");
				row1.createCell(1).setCellValue(a);
				row1.createCell(2).setCellValue("�Ƿ񸶿�");
				row1.createCell(3).setCellValue(flage);
				XSSFRow row3=sheet.createRow(2);
				row3.createCell(0).setCellValue("ҩƷ����");
				row3.createCell(1).setCellValue("����");
				row3.createCell(2).setCellValue("����");
				row3.createCell(3).setCellValue("���");
				
//				��дһ��select ��һ������ֻ�ǲ鿴һ���ֵ�ҩƷ��Ϣ���ú����
				ArrayList Listp = mydao1.findpartdrug3(Integer.valueOf(numm));
				 for(int row4=0;row4<Listp.size();row4++){
					 XSSFRow row5=sheet.createRow(row4+3);
					 String [][] data=new String[Listp.size()] [4];
				    	mytablet d =(mytablet)Listp.get(row4);
				    	data[row4][0]=d.getDrugname();
				    	row5.createCell(0).setCellValue(data[row4][0]);//
				    	data[row4][1]= String.valueOf(d.getDruginventory());
				    	row5.createCell(1).setCellValue(data[row4][1]);//
				    	data[row4][2]=String.valueOf(d.getUnitprice());
				    	row5.createCell(2).setCellValue(data[row4][2]);//
				    	data[row4][3]=String.valueOf(d.getUnitprice()*d.getDruginventory());
				    	row5.createCell(3).setCellValue(data[row4][3]);//
				   	 }	
				int r=sheet.getLastRowNum();
				XSSFRow row4=sheet.createRow(r+1);
				row4.createCell(0).setCellValue("����Ա");
				row4.createCell(1).setCellValue(casids);
				System.out.print(casids);
				FileOutputStream fo;
				try {
					fo = new FileOutputStream("D:\\���˵�.xlsx");
					book.write(fo);
					book.close();
					fo.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			}
		});
		btnNewButton_1.setBounds(315, 576, 113, 27);
		contentPane.add(btnNewButton_1);
	}

}
