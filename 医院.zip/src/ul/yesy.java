package ul;



import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.cashierDao;
import dao.doctordao;
import dao.doctorpass;
import dao.patientDao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import imges.background;
public class yesy extends JFrame {

	private JPanel contentPane;
	
	private JPasswordField passwordField;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					yesy frame = new yesy();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public yesy() {
		setTitle("\u6E58\u6C5FXX\u95E8\u8BCA\u7CFB\u7EDF");
		dispose();
		setBounds(100, 100, 956, 511);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		background back=new background();
		contentPane.add(back);
		back.setLayout(null);
		
		JLabel label = new JLabel("\u8D26\u53F7:");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setForeground(Color.BLACK);
		label.setBounds(257, 81, 59, 32);
		back.add(label);
		
		JLabel label_1 = new JLabel("\u5BC6\u7801:");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(257, 161, 45, 32);
		back.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(356, 87, 188, 32);
		back.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(356, 167, 188, 31);
		back.add(passwordField);
		
		ButtonGroup buttgroup= new ButtonGroup();
		
		JRadioButton radadmin = new JRadioButton("\u7BA1\u7406\u5458");
		radadmin.setBackground(new Color(100, 149, 237));
		radadmin.setBounds(139, 270, 86, 27);
		back.add(radadmin);
		
		JRadioButton raddoctor = new JRadioButton("\u533B\u751F");
		raddoctor.setBackground(new Color(30, 144, 255));
		raddoctor.setBounds(301, 270, 86, 27);
		back.add(raddoctor);
		
		JRadioButton radpatient = new JRadioButton("\u60A3\u8005");
		radpatient.setBackground(new Color(51, 255, 255));
		radpatient.setBounds(492, 270, 86, 27);
		back.add(radpatient);
		
		JRadioButton radcashier = new JRadioButton("\u6536\u94F6\u5458");
		radcashier.setBackground(new Color(153, 255, 255));
		radcashier.setBounds(666, 270, 86, 27);
		back.add(radcashier);
		
		buttgroup.add(radadmin);
		buttgroup.add(raddoctor);
		buttgroup.add(radpatient);
		buttgroup.add(radcashier);
		
		JButton button = new JButton("��¼");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					login();
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			private void login() throws HeadlessException, ClassNotFoundException, SQLException {
				// TODO Auto-generated method stub
				String name =textField.getText();
				String pass=String.valueOf(passwordField.getPassword());
				if(radadmin.isSelected()) {
					if(name.equals("")||pass.equals("")) {
						JOptionPane.showMessageDialog(null, "�˺Ż�������Ϊ��");
					}else if(name.equals("admin")&&pass.equals("admin")) {
							JOptionPane.showMessageDialog(null, "����Ա��¼�ɹ�");
							admitmenu a=new admitmenu();
							a.setVisible(true);
							}else {
								JOptionPane.showMessageDialog(null, "����Ա��½ʧ��");
									}
				}else if(raddoctor.isSelected()) {
					doctorpass docdao =new doctorpass();
					if(name.equals("")||pass.equals("")){
						JOptionPane.showMessageDialog(null, "�˺Ż�������Ϊ��");
					}else if (docdao.login(name,pass)) {
							JOptionPane.showMessageDialog(null, "ҽ����½�ɹ�");
							doctormenu dmenu=new doctormenu(name);
							
							dmenu.setVisible(true);
							
						}else {
							JOptionPane.showMessageDialog(null, "ҽ����½ʧ��");
						}
					} else if(radpatient.isSelected()) {
						patientDao patdao=new patientDao();
						if(name.equals(" ")||pass.equals("")) {
							JOptionPane.showMessageDialog(null, "�˺Ż�������Ϊ��");
						} else if(patdao.login(name, pass)) {
							JOptionPane.showMessageDialog(null, "�û���½�ɹ�");
							usermenu u=new usermenu(name);
							u.setVisible(true);
						}else {
							JOptionPane.showMessageDialog(null, "�û���½ʧ��");
						}
					}if(radcashier.isSelected()) {
						cashierDao casdao =new cashierDao();
						if(name.equals(" ")||pass.equals("")) {
							JOptionPane.showMessageDialog(null, "�˺Ż�������Ϊ��");
						} else if(casdao.login(name, pass)) {
							JOptionPane.showMessageDialog(null, "����Ա��½�ɹ�");
							settleaccountexcel s=new settleaccountexcel(name);
							s.setVisible(true);
						}else {
							JOptionPane.showMessageDialog(null, "����Ա��½ʧ��");
						}
					}
			}
		});
		button.setBounds(210, 378, 113, 27);
		back.add(button);
		
		JButton button_1 = new JButton("\u53D6\u6D88");
		button_1.setBounds(526, 378, 113, 27);
		back.add(button_1);
		
	
	}
}
