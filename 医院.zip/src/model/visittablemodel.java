package model;

import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import bean.doctor;
import bean.visitdoctor;

public class visittablemodel extends DefaultTableModel{
		public visittablemodel(ArrayList list)
		{
			String [] name= {
					"�����","��������","�����Ա�","��������","ҽ��","����","��Ͻ��","�Һŷ���"
			};
			String [][] data=new String[list.size()][name.length];
			int count=0;
		    for(int row=0;row<list.size();row++){
		    	count++;
		    	 visitdoctor d =(visitdoctor)list.get(row);
		    	data[row][0]=d.getVistnum();
		    	data[row][1]=d.getName();
		    	data[row][2]=d.getSex();
		    	data[row][3]=d.getAge();
		    	data[row][4]=d.getMydor();
		    	data[row][5]=d.getRoom();
		    	data[row][6]=d.getResult();
		    	data[row][7]=String.valueOf(d.getFee());
		   	 }
		    this.setDataVector(data, name);
					
					
		}
}
