package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.cj.protocol.Resultset;

import bean.doctor;
import bean.doctorlogin;

public class doctorpass {
	PreparedStatement pstmt;
	Connection conn=new jdbc.JDBC().getconection();
	ResultSet rs;
	public boolean login (String doctorId, String doctorpass) throws ClassNotFoundException, SQLException  {
		boolean flag=true;
		String sql ="SELECT * from ҽ���˺�  WHERE ҽ���˺�=? and ҽ������=?";
		PreparedStatement ps =conn.prepareStatement(sql);
		ps.setString(1, doctorId);
		ps.setString(2, doctorpass);
		ResultSet rs =ps.executeQuery();
		if(rs.next()) {
			flag=true;
		}
		else {
			flag=false;
		}
		return flag;
	}
	public ArrayList<doctorlogin> findlist(String id) throws SQLException
	{
		ArrayList<doctorlogin> list =new ArrayList<>();
		String sql="select * from ҽ���˺� where ҽ���˺�=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			doctorlogin d=new doctorlogin();
			d.setId(rs.getString(1));
			d.setPass(rs.getString(2));
			d.setNum(rs.getInt(3));
			list.add(d);
		}
		return list;
	}
	public ArrayList<doctor> findlistdor(String id) throws SQLException
	{
		ArrayList<doctor> list =new ArrayList<>();
		String sql="SELECT * FROM `ҽ��` WHERE `ҽ�����` IN(SELECT `ҽ�����` FROM `ҽ���˺�` WHERE ҽ���˺�=?)";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			doctor d=new doctor();
			d.setDornumber(rs.getInt(1));
			d.setDorname(rs.getString(2));
			d.setDorroom(rs.getString(3));
			d.setDorprofess(rs.getString(4));
			d.setDortype(rs.getString(5));
			d.setDorfee(rs.getDouble(6));
			list.add(d);
		}
		return list;
	}
}
