package bean;

public class settleaccount {
	String surverynum;
	String name;
	String sflag;
	public String getSurverynum() {
		return surverynum;
	}
	public void setSurverynum(String surverynum) {
		this.surverynum = surverynum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
	public String getSflag() {
		return sflag;
	}
	public void setSflag(String sflag) {
		this.sflag = sflag;
	}
	
}
