package bean;

public class mytablet {
	public int surveynum;
	public int drugid;
	public String drugname;
	public String drugtype;
	public int druginventory;
	public String Shelvesnumber;
	public String unit;
	public String specifications;
	public int unitprice;
	public int getSurveynum() {
		return surveynum;
	}
	public void setSurveynum(int surveynum) {
		this.surveynum = surveynum;
	}
	public int getDrugid() {
		return drugid;
	}
	public void setDrugid(int drugid) {
		this.drugid = drugid;
	}
	public String getDrugname() {
		return drugname;
	}
	public void setDrugname(String drugname) {
		this.drugname = drugname;
	}
	public String getDrugtype() {
		return drugtype;
	}
	public void setDrugtype(String drugtype) {
		this.drugtype = drugtype;
	}
	public int getDruginventory() {
		return druginventory;
	}
	public void setDruginventory(int druginventory) {
		this.druginventory = druginventory;
	}
	public String getShelvesnumber() {
		return Shelvesnumber;
	}
	public void setShelvesnumber(String shelvesnumber) {
		Shelvesnumber = shelvesnumber;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getSpecifications() {
		return specifications;
	}
	public void setSpecifications(String specifications) {
		this.specifications = specifications;
	}
	public int getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(int unitprice) {
		this.unitprice = unitprice;
	}
	
	
	
}
