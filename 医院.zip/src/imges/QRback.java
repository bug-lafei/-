package imges;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class QRback extends JPanel {
	Image im;
	public  QRback() {
		im = new ImageIcon(QRback.class.getResource("test.png")).getImage();
		this.setOpaque(true);
	}
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(im,0,0,this.getWidth(),this.getHeight(),this);
	}
	
}
