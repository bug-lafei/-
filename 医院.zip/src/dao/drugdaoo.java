package dao;


import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.drug;
import bean.drug1;
import bean.mytablet;


public class drugdaoo {
	PreparedStatement pstmt;
	Connection conn=new jdbc.JDBC().getconection();
	ResultSet rs;
	public boolean addoctor(drug1 d) throws SQLException, ClassNotFoundException//����
	{
		
		boolean flag=true;
		String sql="insert into ҩƷ�� values(?,?,?,?,?,?,?,?)";
		pstmt=conn.prepareStatement(sql);
		int i=0;
		pstmt.setInt(1, d.getDrugid());
		pstmt.setString(2, d.getDrugname());
		pstmt.setString(3, d.getDrugtype());
		pstmt.setInt(4, d.getDruginventory());
		pstmt.setString(5, d.getShelvesnumber());
		pstmt.setString(6, d.getUnit());
		pstmt.setString(7, d.getSpecifications());
		pstmt.setInt(8, d.getUnitprice());
		i=pstmt.executeUpdate();
		if(i>0)
		{
			flag=true;
		}
		else {
			flag=false;
		}
		return flag;
	}
	public  boolean deletedrug(int id) throws ClassNotFoundException, SQLException
	{
		int i=0;
		String sql="delete from ҩƷ�� where ҩƷ���=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(i>0)
		{
			return true;
		}
		else {
			return false;
		}
		
	}
	public boolean modify(drug1 d) throws SQLException, ClassNotFoundException
	{
		int i=0;
		boolean flag=true;
		String sql="update ҩƷ�� set ҩƷ���=?,ҩƷ����=?,����=?,���=?,���ܱ��=?,��λ=?,���=?,����=? where ҩƷ���=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1,d.getDrugid());
		pstmt.setString(2,d.getDrugname());
		pstmt.setString(3,d.getDrugtype());
		pstmt.setInt(4,d.getDruginventory());
		pstmt.setString(5,d.getShelvesnumber());
		pstmt.setString(6,d.getUnit());
		pstmt.setString(7,d.getSpecifications());
		pstmt.setInt(8,d.getUnitprice());
		pstmt.setInt(9, d.getDrugid());
		i=pstmt.executeUpdate();
		if(i>0)
		{
			flag=true;
		}
		else{
			flag=false;
		}
		return flag;
	}
	
	public ArrayList<drug1> numshowlist(int drugname) throws SQLException, ClassNotFoundException
	{
		ArrayList<drug1> list=new ArrayList<>();
		String sql="select * from ҩƷ�� where ҩƷ���=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, drugname);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			drug1 d=new drug1();
			d.setDrugid(rs.getInt(1));
			d.setDrugname(rs.getString(2));
			d.setDrugtype(rs.getString(3));
			d.setDruginventory(rs.getInt(4));
			d.setShelvesnumber(rs.getString(5));
			d.setUnit(rs.getString(6));
			d.setSpecifications(rs.getString(7));
			d.setUnitprice(rs.getInt(8));
			list.add(d);
		}
		return list;
	}
	public ArrayList<drug1> showlist() throws SQLException, ClassNotFoundException
	{
		ArrayList<drug1> list=new ArrayList<>();
		String sql="select * from ҩƷ�� ";
		pstmt=conn.prepareStatement(sql);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			drug1 d=new drug1();
			d.setDrugid(rs.getInt(1));
			d.setDrugname(rs.getString(2));
			d.setDrugtype(rs.getString(3));
			d.setDruginventory(rs.getInt(4));
			d.setShelvesnumber(rs.getString(5));
			d.setUnit((rs.getString(6)));
			d.setSpecifications(rs.getString(7));
			d.setUnitprice(rs.getInt(8));
			list.add(d);
		}
		return list;
	}
	public ArrayList<mytablet> findpartdrug(int id)
	{
		ArrayList<mytablet> list=new ArrayList<>();
		String sql="select �����,ҩƷ����,��λ,���,���� from ҩƷ where �����=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				mytablet m=new mytablet();
				m.setSurveynum(rs.getInt(1));
				m.setDrugname(rs.getString(2));
				m.setUnit(rs.getString(3));
				m.setSpecifications(rs.getString(4));
				m.setDruginventory(rs.getInt(5));
				list.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	public ArrayList<mytablet> findpartdrug2(int id)
	{
		ArrayList<mytablet> list=new ArrayList<>();
		String sql="select �����,ҩƷ����,��λ,���,���� from ҩƷ where �����=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				mytablet m=new mytablet();
				m.setSurveynum(rs.getInt(1));
				m.setDrugname(rs.getString(2));
				m.setUnit(rs.getString(3));
				m.setSpecifications(rs.getString(4));
				m.setDruginventory(rs.getInt(5));
				list.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	public ArrayList<mytablet> findpartdrug3(int id)
	{
		ArrayList<mytablet> list=new ArrayList<>();
		String sql="select ҩƷ����,����,���� from ҩƷ where �����=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				mytablet m=new mytablet();
				m.setDrugname(rs.getString(1));
				m.setDruginventory(rs.getInt(2));
				m.setUnitprice(rs.getInt(2));
				list.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
}
