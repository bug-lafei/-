package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.doctor;
import dao.doctordao;
import model.doctortable;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Lookdoctor extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Lookdoctor frame = new Lookdoctor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public Lookdoctor() throws SQLException {
		doctordao dao=new doctordao();
		doctortable dtablemodel;
		dispose();
		setBounds(100, 100, 585, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 45, 567, 232);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row=table.getSelectedRow();
				textField_1.setText(String.valueOf(table.getValueAt(row, 0)));
				textField_2.setText(String.valueOf(table.getValueAt(row, 1)));
				textField_3.setText(String.valueOf(table.getValueAt(row, 2)));
				textField_4.setText(String.valueOf(table.getValueAt(row, 3)));
				textField_5.setText(String.valueOf(table.getValueAt(row, 4)));
				textField_6.setText(String.valueOf(table.getValueAt(row, 5)));
				
			}
		});
		List list =dao.showlist();
		dtablemodel=new doctortable(list);
		table.setModel(dtablemodel);
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.setBounds(207, 13, 147, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("��ѯ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ArrayList<doctor> list =dao.Nshowlist(textField.getText());
					doctortable dtablemodel2 =new doctortable(list);
					table.setModel(dtablemodel2);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
 			}
		});
		btnNewButton.setBounds(368, 12, 90, 27);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("ҽ�����");
		lblNewLabel.setBounds(95, 16, 72, 18);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ҽ�����");
		lblNewLabel_1.setBounds(46, 290, 72, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("ҽ������");
		lblNewLabel_2.setBounds(46, 339, 72, 18);
		contentPane.add(lblNewLabel_2);
		
		JLabel label = new JLabel("����");
		label.setBounds(46, 387, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("ְ��");
		label_1.setBounds(315, 290, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("��������");
		label_2.setBounds(315, 339, 72, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("�������");
		label_3.setBounds(315, 387, 72, 18);
		contentPane.add(label_3);
		
		textField_1 = new JTextField();
		textField_1.setBounds(132, 290, 129, 24);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(132, 336, 129, 24);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(132, 384, 129, 24);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(411, 287, 129, 24);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(411, 336, 129, 24);
		contentPane.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(411, 384, 129, 24);
		contentPane.add(textField_6);
		
		JButton btnNewButton_1 = new JButton("�޸�");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				doctor d=new doctor();
				d.setDornumber(Integer.valueOf(textField_1.getText()));
				d.setDorname(textField_2.getText());
				d.setDorroom(textField_3.getText());
				d.setDorprofess(textField_4.getText());
				d.setDortype(textField_5.getText());
				d.setDorfee(Double.parseDouble(textField_6.getText()));
				try {
					if(dao.modify(d))
					{
						JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
						
					}
					else {
						JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ������Ƿ�Ϊ�ա������ظ�");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(14, 448, 113, 27);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("ɾ��");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(dao.deletecourse(textField_1.getText()))
				{
					JOptionPane.showMessageDialog(null, "ɾ���ɹ���");
					table.updateUI();
				}
				else if(textField_1.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "������Ϊ��Ŷ");
				}
				else {
					JOptionPane.showMessageDialog(null, "����ɾ����Ӧ�ĹҺŵ�Ŷ");
				}
			}
		});
		btnNewButton_2.setBounds(241, 448, 113, 27);
		contentPane.add(btnNewButton_2);
		
		
		
		JButton button = new JButton("ˢ��");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<doctor> list;
				try {
					list = dao.showlist();
					doctortable	dtablemodel3=new doctortable(list);
					table.setModel(dtablemodel3);
					table.updateUI();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		button.setBounds(454, 448, 113, 27);
		contentPane.add(button);
	}
}
