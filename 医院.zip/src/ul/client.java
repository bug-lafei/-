package ul;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class client extends JFrame implements Runnable{
    private JTextField jtf = new JTextField();
    private JTextArea jta = new JTextArea();  
    private JButton jbSend = new JButton("Send"); 
    private DataOutputStream toServer;
    private DataInputStream fromServer;
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Date d = new Date();
    String time = format.format(d);

    public static void main(String[] args) {
    	client c=new client();
    	c.setVisible(true);
        new Thread(c).start();
    }

    public client() {
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel p = new JPanel();
        p.setLayout(new BorderLayout());
        p.add(new JLabel("Message"), BorderLayout.WEST);
        p.add(jtf, BorderLayout.CENTER);
        jtf.setHorizontalAlignment(JTextField.LEFT);
        p.add(jbSend, BorderLayout.EAST);
        setLayout(new BorderLayout());
        add(p, BorderLayout.SOUTH);
        add(new JScrollPane(jta), BorderLayout.CENTER);

        jtf.addActionListener(new ButtonListener()); 
        jbSend.addActionListener(new ButtonListener()); 
        
        setTitle("�û�");
        setSize(500, 300);
        dispose();
        setVisible(true); 
       
    }

    public class ButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                // Get the message from the text field
                String message = jtf.getText().trim();

                // Send the message to the server
                toServer.writeUTF(message);
                toServer.flush();

                // Display to the text area
                jta.append(" " + time + '\n');
                jta.append(" MyMessage: " + message + "\n");
                jtf.setText(null);
            } catch (IOException ex) {
                System.err.println(ex);
            }
        }
    }

	@Override
	public void run() {
		// TODO Auto-generated method stub
		 try {
	            Socket socket = new Socket(InetAddress.getLocalHost(),8011);
	            socket.setReuseAddress(true);
	            fromServer = new DataInputStream(socket.getInputStream());
	            toServer = new DataOutputStream(socket.getOutputStream());
	            
	            while (true) {
	                
	                String message2 = fromServer.readUTF();
	                jta.append(" " + time + '\n');
	                jta.append(" Message: " + message2 + '\n');
	            }
	        } catch (IOException ex) {
	            jta.append(" ***�Է��Ѿ�����!*** "+ '\n');
	        }
	}
}
