package bean;
public class doctor {
	private int dornumber;
	private String dorname;
	private String dorprofess;
	private String dorroom;
	private String dortype;
	private double dorfee;
	public int getDornumber() {
		return dornumber;
	}
	public void setDornumber(int dornumber) {
		this.dornumber = dornumber;
	}
	public String getDorname() {
		return dorname;
	}
	public void setDorname(String dorname) {
		this.dorname = dorname;
	}
	public String getDorprofess() {
		return dorprofess;
	}
	public void setDorprofess(String dorprofess) {
		this.dorprofess = dorprofess;
	}
	public String getDorroom() {
		return dorroom;
	}
	public void setDorroom(String dorroom) {
		this.dorroom = dorroom;
	}
	public String getDortype() {
		return dortype;
	}
	public void setDortype(String dortype) {
		this.dortype = dortype;
	}
	public double getDorfee() {
		return dorfee;
	}
	public void setDorfee(double dorfee) {
		this.dorfee = dorfee;
	}
	
	
}
