package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.doctor;
import bean.drug1;
import dao.drugdaoo;
import model.doctortable;
import model.drugtablemodel;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Lookdrug extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Lookdrug frame = new Lookdrug();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Lookdrug() {
		dispose();
		setBounds(100, 100, 604, 528);
		drugtablemodel tablemodel;
		drugdaoo dao=new drugdaoo();
		drug1 d=new drug1();
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 43, 586, 236);
		contentPane.add(scrollPane);
		
		
		
		JLabel lblNewLabel = new JLabel("ҩƷ���");
		lblNewLabel.setBounds(37, 292, 72, 18);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ҩƷ����");
		lblNewLabel_1.setBounds(37, 337, 72, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel label = new JLabel("����");
		label.setBounds(37, 378, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("���");
		label_1.setBounds(37, 424, 72, 18);
		contentPane.add(label_1);
		
		
		
		textField = new JTextField();
		textField.setBounds(135, 289, 118, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(135, 334, 118, 24);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(135, 375, 118, 24);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(135, 418, 118, 24);
		contentPane.add(textField_3);
		
		JLabel label_2 = new JLabel("���ܱ��");
		label_2.setBounds(294, 292, 72, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("��λ");
		label_3.setBounds(294, 337, 72, 18);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("���");
		label_4.setBounds(294, 378, 72, 18);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("����");
		label_5.setBounds(294, 424, 72, 18);
		contentPane.add(label_5);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(405, 289, 118, 24);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(405, 334, 118, 24);
		contentPane.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(405, 375, 118, 24);
		contentPane.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(405, 421, 118, 24);
		contentPane.add(textField_7);
		
		JButton button = new JButton("ɾ��");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(dao.deletedrug(Integer.valueOf(textField.getText())))
					{
						JOptionPane.showMessageDialog(null, "ɾ���ɹ���");
						table.updateUI();
					}
					else if(textField.getText().equals(""))
					{
						JOptionPane.showMessageDialog(null, "������Ϊ��Ŷ");
					}
					else {
						JOptionPane.showMessageDialog(null, "����ɾ����Ӧ�ĹҺŵ�Ŷ");
					}
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button.setBounds(194, 455, 113, 27);
		contentPane.add(button);
		
		JButton button_1 = new JButton("ˢ��");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<drug1> list;
				try {
					list = dao.showlist();
					drugtablemodel	dtablemodel3=new drugtablemodel(list);
					table.setModel(dtablemodel3);
					table.updateUI();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		button_1.setBounds(395, 455, 113, 27);
		contentPane.add(button_1);
		
		textField_8 = new JTextField();
		textField_8.setBounds(221, 13, 102, 24);
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("ҩƷ��");
		lblNewLabel_2.setBounds(135, 16, 72, 18);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("��ѯ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ArrayList<drug1> list =dao.numshowlist(Integer.valueOf(textField_8.getText()));
					drugtablemodel dtablemodel2 =new drugtablemodel(list);
					table.setModel(dtablemodel2);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		btnNewButton_1.setBounds(337, 12, 113, 27);
		contentPane.add(btnNewButton_1);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row=table.getSelectedRow();
				textField.setText(String.valueOf(table.getValueAt(row, 0)));
				textField_1.setText(String.valueOf(table.getValueAt(row, 1)));
				textField_2.setText(String.valueOf(table.getValueAt(row, 2)));
				textField_3.setText(String.valueOf(table.getValueAt(row, 3)));
				textField_4.setText(String.valueOf(table.getValueAt(row, 4)));
				textField_5.setText(String.valueOf(table.getValueAt(row, 5)));
				textField_6.setText(String.valueOf(table.getValueAt(row, 6)));
				textField_7.setText(String.valueOf(table.getValueAt(row, 7)));			
			}
		});
		try {
			ArrayList<drug1> list=dao.showlist();
			tablemodel=new drugtablemodel(list);
			table.setModel(tablemodel);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("�޸�");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.setDrugid(Integer.valueOf(textField.getText()));
				d.setDrugname(textField_1.getText());
				d.setDrugtype(textField_2.getText());
				d.setDruginventory(Integer.valueOf(textField_3.getText()));
				d.setShelvesnumber(textField_4.getText());
				d.setUnit(textField_5.getText());
				d.setSpecifications(textField_6.getText());
				d.setUnitprice(Integer.valueOf(textField_7.getText()));
				try {
					if(dao.modify(d))
					{
						JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
					}
					else {
						JOptionPane.showMessageDialog(null, "�޸�ʧ�ܣ������Ƿ�Ϊ�ա������ظ�");
					}
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(32, 455, 113, 27);
		contentPane.add(btnNewButton);
	}
}
