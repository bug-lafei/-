package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import bean.doctor;
import bean.drug1;
import bean.mytablet;
import dao.doctorpass;
import dao.dragDao;
import dao.drugdaoo;
import dao.patientDao;
import model.mydrugmodel;
import model.visittablemodel;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.io.IOException;

public class patientexcel extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	static int  value;
	static String name;
	static String sex;
	static String age;
	static String room;
	static String result;
	static String mydoctor;
	static String unit;
	String much;
	String size;
	static int mynum;
	 static ArrayList<mytablet> Listp=new ArrayList<>();
	static ArrayList<mytablet> mylist;
	mydrugmodel mytablemodel;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					patientexcel frame = new patientexcel();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public patientexcel(String num) throws SQLException, ClassNotFoundException {
		visittablemodel tablemodel;
		doctorpass ddao=new doctorpass();
		patientDao pdao=new patientDao();
		drugdaoo wdao=new drugdaoo();
		dragDao mydao=new dragDao();
		dispose();
		setBounds(100, 100, 626, 606);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 32, 608, 205);
		contentPane.add(scrollPane);
		
		
		
		JLabel lblNewLabel = new JLabel("��Ӧ��ҩƷ");
		lblNewLabel.setBounds(0, 250, 113, 18);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 277, 608, 226);
		contentPane.add(scrollPane_1);
		
		
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					excel();
				} catch (InvalidFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(53, 519, 113, 27);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("����");
		btnNewButton_2.setBounds(424, 519, 113, 27);
		contentPane.add(btnNewButton_2);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row=table.getSelectedRow();
				value=Integer.valueOf((String) table.getValueAt(row, 0));//��
				name=String.valueOf(table.getValueAt(row, 1));//����
				sex=String.valueOf(table.getValueAt(row, 2));//�Ա�
				age=String.valueOf(table.getValueAt(row, 3));//����
				mydoctor=String.valueOf(table.getValueAt(row, 4));//ҽ��
				room=String.valueOf(table.getValueAt(row, 5));//����
				result=String.valueOf(table.getValueAt(row, 6));//���
				mytablet man;
				Listp=wdao.findpartdrug(value);
				man=Listp.get(0);
				System.out.print(value);
				table_1 = new JTable();
				table_1.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						int row=table_1.getSelectedRow();
//						mynum=Integer.valueOf((String) table_1.getValueAt(row, 1));
//						value=String.valueOf(table_1.getValueAt(row, 2));//����
//						much=String.valueOf(table_1.getValueAt(row, 4));//����
//						unit=String.valueOf(table_1.getValueAt(row, 6));//��λ
//						size=String.valueOf(table_1.getValueAt(row, 7));//���
						
					}
				});
				
				try {
					mylist = mydao.findnum(value);
					mytablemodel=new mydrugmodel(mylist);
					table_1.setModel(mytablemodel);
					scrollPane_1.setViewportView(table_1);
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
		scrollPane.setViewportView(table);
		ArrayList<doctor> patientlist=ddao.findlistdor(num);
		doctor d=patientlist.get(0);
		ArrayList list=pdao.listdoctor(d.getDorname());
		tablemodel=new visittablemodel(list);
		table.setModel(tablemodel);	
	}
	public static void excel() throws IOException, InvalidFormatException
	{
//		File f=new File("D:\\����5.xlsx");
		XSSFWorkbook book =new XSSFWorkbook();
		XSSFSheet sheet =book.createSheet("ҽԺ����");	 
		XSSFRow row=sheet.createRow(0);
		row.createCell(0).setCellValue("�����");
		row.createCell(1).setCellValue(value);
		row.createCell(2).setCellValue("����");
		row.createCell(3).setCellValue(name);
		row.createCell(4).setCellValue("�Ա�");
		row.createCell(5).setCellValue(sex);
		XSSFRow row1=sheet.createRow(1);
		row1.createCell(0).setCellValue("����");
		row1.createCell(1).setCellValue(age);
		row1.createCell(2).setCellValue("����");
		row1.createCell(3).setCellValue(room);
		row1.createCell(4).setCellValue("��Ͻ��");
		row1.createCell(5).setCellValue(result);
		XSSFRow row2=sheet.createRow(2);
		row2.createCell(0).setCellValue("����:");
		XSSFRow row3=sheet.createRow(3);
		row3.createCell(0).setCellValue("�����");
		row3.createCell(1).setCellValue("ҩƷ����");
		row3.createCell(2).setCellValue("��λ");
		row3.createCell(3).setCellValue("���");
		row3.createCell(4).setCellValue("����");
		
		 for(int row4=0;row4<Listp.size();row4++){
			 XSSFRow row5=sheet.createRow(row4+4);
			 String [][] data=new String[Listp.size()] [5];
		    	mytablet d =(mytablet)Listp.get(row4);
		    	data[row4][0]=String.valueOf(d.getSurveynum());
		    	row5.createCell(0).setCellValue(data[row4][0]);
		    	data[row4][1]=d.getDrugname();
		    	row5.createCell(1).setCellValue(data[row4][1]);
		    	data[row4][2]= String.valueOf(d.getSpecifications());
		    	row5.createCell(2).setCellValue(data[row4][2]);
		    	data[row4][3]=d.getUnit();
		    	row5.createCell(3).setCellValue(data[row4][3]);
		    	data[row4][4]=String.valueOf(d.getDruginventory());
		    	row5.createCell(4).setCellValue(data[row4][4]);
		   	 }
		
		int r=sheet.getLastRowNum();
		XSSFRow row4=sheet.createRow(r+1);
		row4.createCell(0).setCellValue("ҽ������");
		row4.createCell(1).setCellValue(mydoctor);
		FileOutputStream fo=new FileOutputStream("D:\\���Դ�����.xlsx");
		book.write(fo);
		book.close();
		fo.close();
		JOptionPane.showMessageDialog(null, "�Ѿ�������");
	}
}
