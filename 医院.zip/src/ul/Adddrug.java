package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.drug1;
import dao.drugdaoo;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Adddrug extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Adddrug frame = new Adddrug();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Adddrug() {
		dispose();
		drugdaoo dao=new drugdaoo();
		drug1 d=new drug1();
		setBounds(100, 100, 607, 642);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ҩƷ���");
		lblNewLabel.setBounds(81, 50, 92, 18);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("ҩƷ����");
		label.setBounds(81, 118, 92, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("����");
		label_1.setBounds(81, 186, 92, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("���");
		label_2.setBounds(81, 254, 92, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("��λ");
		label_3.setBounds(81, 322, 92, 18);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("\u8D27\u67B6\u7F16\u53F7");
		label_4.setBounds(81, 383, 92, 18);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("����");
		label_5.setBounds(81, 513, 92, 18);
		contentPane.add(label_5);
		
		
		
		JButton btnNewButton_1 = new JButton("���");
		btnNewButton_1.setBounds(380, 555, 113, 27);
		contentPane.add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setBounds(207, 55, 181, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(207, 120, 181, 24);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(207, 185, 181, 24);
		contentPane.add(textField_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(207, 315, 181, 24);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(207, 380, 181, 24);
		contentPane.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(207, 510, 181, 24);
		contentPane.add(textField_6);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(207, 250, 175, 24);
		contentPane.add(spinner);
		
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(207, 445, 181, 24);
		contentPane.add(textField_3);
		
		JButton btnNewButton = new JButton("����");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				d.setDrugid(Integer.valueOf(textField.getText()));
				d.setDrugname(textField_1.getText());
				d.setDrugtype(textField_2.getText());
				d.setDruginventory(Integer.valueOf((String) spinner.getValue()));
				d.setUnit(textField_4.getText());
				d.setShelvesnumber(textField_5.getText());
				d.setUnitprice(Integer.valueOf(textField_6.getText()));
				d.setSpecifications(textField_3.getText());
				try {
					if(dao.addoctor(d))
					{
						JOptionPane.showMessageDialog(null, "���ӳɹ���");
					}
					else {
						JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");
					}
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(60, 555, 113, 27);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("���");
		lblNewLabel_1.setBounds(82, 448, 72, 18);
		contentPane.add(lblNewLabel_1);
		
		
	}
}
