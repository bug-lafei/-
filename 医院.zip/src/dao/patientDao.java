package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import bean.patient;
import bean.visitdoctor;
public class patientDao {
	PreparedStatement pstmt;
	Connection conn=new jdbc.JDBC().getconection();
	ResultSet rs;
	public boolean login(String patientid, String patientpass) throws ClassNotFoundException, SQLException {
		boolean flag=true;
		String sql ="SELECT * from �����˺�  WHERE �˺�=? and ����=?";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, patientid);
		ps.setString(2, patientpass);
		ResultSet rs =ps.executeQuery();
		if(rs.next()) {
			flag=true;
		}else {
			flag=false;
		}
		return flag;
	}
	public ArrayList<patient> showlist(String id) throws SQLException
	{
		ArrayList<patient> list =new ArrayList<>();
		String sql="select * from �����˺�  where �˺�=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			patient p=new patient();
			p.setPatientid(rs.getString(1));
			p.setPainentpass(rs.getString(2));
			p.setName(rs.getString(3));
			p.setNum(rs.getString(4));
			p.setSex(rs.getString(5));
			p.setAge(rs.getString(6));
			list.add(p);
		}
		return list;
		
	}
	public boolean modifyStuInfo(patient p){
		int i=0;
		try{
			String updatesql="update �����˺� set ����=?,"
					+"����=?,"
					+"����֤��=?,"
					+"�Ա�=?,"
					+"����=?"
					+" where �˺�=?";						
			pstmt=conn.prepareStatement(updatesql);
			pstmt.setString(1, p.getPainentpass());
			pstmt.setString(2, p.getName());
			pstmt.setString(3, p.getNum());
			pstmt.setString(4, p.getSex());
			pstmt.setString(5, p.getAge());
			pstmt.setString(6, p.getPatientid());
			i=pstmt.executeUpdate();
		}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
		}
		if(i>0){
			return true;
		}
		else {
			return false;
		}
	}
	public boolean addmajor(visitdoctor v) {
		boolean falg=false;
		String sql="insert into ����(�����,��������,�����Ա�,��������,ҽ��,����,��Ͻ��,�Һŷ���) value(?,?,?,?,?,?,?,?)";
		try {
			
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,v.getVistnum());
			pstmt.setString(2,v.getName());
			pstmt.setString(3,v.getSex());
			pstmt.setString(4,v.getAge());
			pstmt.setString(5,v.getMydor());
			pstmt.setString(6,v.getRoom());
			pstmt.setString(7,v.getResult());
			pstmt.setString(8,String.valueOf(v.getFee()));
			if(pstmt.executeUpdate()>0){
				falg=true;
			}
			else{
				falg=false;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return falg;
	}
	public ArrayList<visitdoctor> listdoctor(String id) throws SQLException
	{
		ArrayList<visitdoctor> list =new ArrayList<>();
		String sql="select * from ���� where ҽ��=?";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, id);
		rs=pstmt.executeQuery();
		while(rs.next())
		{
			visitdoctor p=new visitdoctor();
			p.setVistnum(rs.getString(1));
			p.setName(rs.getString(2));
			p.setSex(rs.getString(3));
			p.setAge(rs.getString(4));
			p.setMydor(rs.getString(5));
			p.setRoom(rs.getString(6));
			p.setResult(rs.getString(7));
			p.setFee(rs.getDouble(8));
			list.add(p);
		}
		return list;
	}
	public boolean modfiyinfo(visitdoctor v) {
		boolean falg=false;
		String sql="update ���� set ��Ͻ��=? where �����=?";
		try {
			
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,v.getResult());
			pstmt.setString(2,v.getVistnum());
			
			if(pstmt.executeUpdate()>0){
				falg=true;
			}
			else{
				falg=false;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return falg;
	}
}
