package bean;

public class visitdoctor {
	String vistnum;
	String name;
	String result;
	String sex;
	String mydor;
	String room;
	String age;
	double fee;
	public String getMydor() {
		return mydor;
	}
	public void setMydor(String mydor) {
		this.mydor = mydor;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getVistnum() {
		return vistnum;
	}
	public void setVistnum(String vistnum) {
		this.vistnum = vistnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	
}
