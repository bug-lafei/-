package model;

import java.util.List;

import javax.swing.table.DefaultTableModel;

import bean.drug1;
import bean.mytablet;

public class mydrugmodel extends DefaultTableModel{
		public mydrugmodel(List list)
		{
			String [] name= {"ҩƷ���","�����","ҩƷ����","����","����","���ܱ��","��λ","���","����"};
			String [][] data=new String[list.size()] [name.length];
			int count=0;
		    for(int row=0;row<list.size();row++){
		    	count++;
		    	 mytablet d =(mytablet)list.get(row);
		    	data[row][0]=String.valueOf(d.getDrugid());
		    	data[row][1]=String.valueOf(d.getSurveynum());
		    	data[row][2]=d.getDrugname();
		    	data[row][3]=d.getDrugtype();
		    	data[row][4]= String.valueOf(d.getDruginventory());
		    	data[row][5]=d.getShelvesnumber();
		    	data[row][6]=d.getUnit();
		    	data[row][7]=d.getSpecifications();
		    	data[row][8]=String.valueOf(d.getUnitprice());
		    	
		   	 }
		    this.setDataVector(data, name);
		}
}
