package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.doctor;
import bean.visitdoctor;
import dao.doctordao;
import dao.patientDao;
import model.doctortable;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import java.awt.event.ActionEvent;

public class everydoctor extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public everydoctor(String account,String pass,String name,String fname,String num,String sex,String age) throws SQLException {
		dispose();
		doctordao dao=new doctordao();
		doctortable dtablemodel;
		setBounds(100, 100, 709, 531);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 32, 691, 243);
		contentPane.add(scrollPane);
	
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(150, 324, 113, 24);
		contentPane.add(comboBox);
		
		JLabel label = new JLabel("ҽ�����");
		label.setBounds(53, 377, 72, 18);
		contentPane.add(label);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(150, 374, 113, 24);
		contentPane.add(comboBox_1);
		
		JLabel label_1 = new JLabel("ҽ������");
		label_1.setBounds(53, 418, 72, 18);
		contentPane.add(label_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(150, 415, 113, 24);
		contentPane.add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setBounds(492, 324, 113, 24);
		contentPane.add(comboBox_3);
		
		JLabel label_2 = new JLabel("����");
		label_2.setBounds(53, 327, 72, 18);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("ְ��");
		label_3.setBounds(378, 327, 72, 18);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("��������");
		label_4.setBounds(378, 377, 72, 18);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("�������");
		label_5.setBounds(378, 418, 72, 18);
		contentPane.add(label_5);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(492, 374, 113, 24);
		contentPane.add(comboBox_4);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setBounds(492, 415, 113, 24);
		contentPane.add(comboBox_5);
		
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setBounds(462, 452, 113, 27);
		contentPane.add(btnNewButton_1);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row=table.getSelectedRow();
				comboBox.addItem(String.valueOf(table.getValueAt(row, 2)));//����
				comboBox_1.addItem(String.valueOf(table.getValueAt(row, 0)));//���
				comboBox_2.addItem(String.valueOf(table.getValueAt(row, 1)));//����
				comboBox_3.addItem(String.valueOf(table.getValueAt(row, 3)));//ְ��
				comboBox_4.addItem(String.valueOf(table.getValueAt(row, 4)));//��������
				comboBox_5.addItem(String.valueOf(table.getValueAt(row, 5)));//�������
			}
		});
		if(name.equals("�ڿ�"))
		{
		
			List list1 =dao.Nshowlist(name);
			dtablemodel=new doctortable(list1);
			table.setModel(dtablemodel);
			scrollPane.setViewportView(table);
		}
		if(name.equals("����"))
		{
			List list1 =dao.Nshowlist(name);
			dtablemodel=new doctortable(list1);
			table.setModel(dtablemodel);
			scrollPane.setViewportView(table);
		}
		if(name.equals("������"))
		{
			List list1 =dao.Nshowlist(name);
			dtablemodel=new doctortable(list1);
			table.setModel(dtablemodel);
			scrollPane.setViewportView(table);
		}
		if(name.equals("�����"))
		{
			List list1 =dao.Nshowlist(name);
			dtablemodel=new doctortable(list1);
			table.setModel(dtablemodel);
			scrollPane.setViewportView(table);
		}
		if(name.equals("��ٿ�"))
		{
			List list1 =dao.Nshowlist(name);
			dtablemodel=new doctortable(list1);
			table.setModel(dtablemodel);
			scrollPane.setViewportView(table);
		}
		if(name.equals("�ǿ�"))
		{
			List list1 =dao.Nshowlist(name);
			dtablemodel=new doctortable(list1);
			table.setModel(dtablemodel);
			scrollPane.setViewportView(table);
		}
		if(name.equals("��ҽ��"))
		{
			List list1 =dao.Nshowlist(name);
			dtablemodel=new doctortable(list1);
			table.setModel(dtablemodel);
			scrollPane.setViewportView(table);
		}
		

		JButton btnNewButton = new JButton("Ԥ��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				patientDao pdao=new patientDao();
				if(fname==null||num==null||age==null||sex==null)
				{
					Object[] options = {"ȷ��","ȡ��",};
	                int response=JOptionPane.showOptionDialog(null,"�㻹û��ʵ�����Ƿ�ǰ��ȥʵ����", "��ʾ",JOptionPane.YES_OPTION,
	                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
	                if(response==0) {
	                	pearonmenu pmenu=new pearonmenu(account, pass, fname, num, sex, age);
	                	pmenu.setVisible(true);
	                		}
	                else if(response==1) {
	                	JOptionPane.showMessageDialog(null, "�Ѿ�����");
	                	}
				}
				else if(fname!=null||num!=null||age!=null||sex!=null)
				{
					if(!comboBox.getSelectedItem().equals("")||!comboBox_1.getSelectedItem().equals("")||!comboBox_2.getSelectedItem().equals("")||!comboBox_3.getSelectedItem().equals("")||!comboBox_4.getSelectedItem().equals("")||!comboBox_5.getSelectedItem().equals(""))
					{
						StringBuilder str=new StringBuilder();
						Random random=new Random();
						for(int i=0;i<8;i++){
							str.append(random.nextInt(10));
						}
						int num=Integer.parseInt(str.toString());
						visitdoctor v=new visitdoctor();
						v.setVistnum(String.valueOf(num));
						v.setName(fname);
						v.setSex(sex);
						v.setAge(age);
						v.setMydor(String.valueOf(comboBox_2.getSelectedItem()));
						v.setRoom(String.valueOf(comboBox.getSelectedItem()));
						v.setResult("�ȴ�����");
						v.setFee(Double.parseDouble((String) comboBox_5.getSelectedItem()));
						if(pdao.addmajor(v))
						{
							QRframe q=new QRframe();
							q.setVisible(true);
//							JOptionPane.showMessageDialog(null, "Ԥ���ɹ����뼰ʱ����");
						}
						//�ò�ѯ������дһ�����û���һ���Һŵ��Ľ��û�е�ʱ�򣬾Ͳ���������ȥ�Һ�
					}
					else if(comboBox.getSelectedItem().equals("")||comboBox_1.getSelectedItem().equals("")||comboBox_2.getSelectedItem().equals("")||comboBox_3.getSelectedItem().equals("")||comboBox_4.getSelectedItem().equals("")||comboBox_5.getSelectedItem().equals("")){
						JOptionPane.showMessageDialog(null, "���ȵ���б�����ȡ��Ϣ��");
					}
					
				}
				
			}
		});
		btnNewButton.setBounds(84, 449, 113, 27);
		contentPane.add(btnNewButton);
		
	}
}
