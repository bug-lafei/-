package bean;

public class drug {
	public String drugid;
	public String drugname;
	public String drugtype;
	public String druginventory;
	public String Shelvesnumber;
	public String unit;
	public String specifications;
	public String unitprice;
	
	
	public String getDragid() {
		return drugid;
	}
	public void setDragid(String dragid) {
		this.drugid = dragid;
	}
	public String getDragname() {
		return drugname;
	}
	public void setDragname(String dragname) {
		this.drugname = dragname;
	}
	public String getDrugtype() {
		return drugtype;
	}
	public void setDrugtype(String drugtype) {
		drugtype = drugtype;
	}
	public String getDruginventory() {
		return druginventory;
	}
	public void setDruginventory(String druginventory) {
		druginventory = druginventory;
	}
	public String getShelvesnumber() {
		return Shelvesnumber;
	}
	public void setShelvesnumber(String shelvesnumber) {
		Shelvesnumber = shelvesnumber;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getSpecifications() {
		return specifications;
	}
	public void setSpecifications(String specifications) {
		this.specifications = specifications;
	}
	public String getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(String unitprice) {
		this.unitprice = unitprice;
	}
	
}
