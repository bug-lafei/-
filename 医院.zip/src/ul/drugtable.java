package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.drug;
import bean.drug1;
import bean.mytablet;
import dao.dragDao;
import dao.drugdaoo;
import model.drugtablemodel;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JComboBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class drugtable extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	private JTextField textField_1;
	private JTextField textField_2;
	int row=0;
	/**
	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					drugtable frame = new drugtable();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public drugtable(int id) throws ClassNotFoundException, SQLException {
		dragDao daoo=new dragDao();
		drugdaoo dao=new drugdaoo();
		drugtablemodel tablemodel;
		dispose();
		setBounds(100, 100, 733, 575);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 50, 715, 220);
		contentPane.add(scrollPane);
		
		
		textField = new JTextField();
		textField.setBounds(214, 13, 123, 35);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ҩƷ����");
		lblNewLabel.setBounds(128, 19, 72, 18);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("��ѯ");
		btnNewButton.setBounds(363, 17, 113, 27);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("ҩƷ���");
		lblNewLabel_1.setBounds(50, 315, 72, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel label = new JLabel("ҩƷ����");
		label.setBounds(50, 358, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("����");
		label_1.setBounds(50, 401, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("���");
		label_2.setBounds(50, 444, 72, 18);
		contentPane.add(label_2);
		
		
		
		
		
		JLabel label_3 = new JLabel("���ܱ��");
		label_3.setBounds(389, 315, 72, 18);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("��λ");
		label_4.setBounds(389, 358, 72, 18);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("���");
		label_5.setBounds(389, 401, 72, 18);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("����");
		label_6.setBounds(389, 444, 72, 18);
		contentPane.add(label_6);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(147, 315, 139, 24);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(147, 358, 139, 24);
		contentPane.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(147, 398, 139, 24);
		contentPane.add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setBounds(504, 441, 139, 24);
		contentPane.add(comboBox_3);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(504, 315, 139, 24);
		contentPane.add(comboBox_4);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setBounds(504, 355, 139, 24);
		contentPane.add(comboBox_5);
		
		JComboBox comboBox_6 = new JComboBox();
		comboBox_6.setBounds(504, 398, 139, 24);
		contentPane.add(comboBox_6);
		
		textField_1 = new JTextField();
		textField_1.setBounds(147, 441, 139, 24);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("��Ҫ��");
		lblNewLabel_2.setBounds(201, 283, 72, 18);
		contentPane.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(298, 283, 86, 24);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		table = new JTable();
		ArrayList<drug1> list=dao.showlist();
		tablemodel=new drugtablemodel(list);
		table.setModel(tablemodel);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				row=table.getSelectedRow();
				comboBox.addItem(String.valueOf(table.getValueAt(row, 0)));
				comboBox_1.addItem(String.valueOf(table.getValueAt(row, 1)));
				comboBox_2.addItem(String.valueOf(table.getValueAt(row, 2)));
				comboBox_3.addItem(String.valueOf(table.getValueAt(row, 7)));
				comboBox_4.addItem(String.valueOf(table.getValueAt(row, 4)));
				comboBox_5.addItem(String.valueOf(table.getValueAt(row, 5)));
				comboBox_6.addItem(String.valueOf(table.getValueAt(row, 6)));
				textField_1.setText((String) table.getValueAt(row, 3));
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int a=Integer.valueOf(textField_1.getText())-Integer.valueOf(textField_2.getText());
				drug1 d=new drug1();
				mytablet m=new mytablet();
				 m.setDrugid(Integer.valueOf((String) comboBox.getSelectedItem()));
				 m.setDrugname((String)comboBox_1.getSelectedItem());
				 m.setDrugtype((String)comboBox_2.getSelectedItem());
				 m.setDruginventory(Integer.valueOf(textField_2.getText()));
				 m.setShelvesnumber((String)comboBox_4.getSelectedItem());
				 m.setUnit(String.valueOf(comboBox_5.getSelectedItem()));
				 m.setSpecifications((String)comboBox_6.getSelectedItem());
				 m.setUnitprice(Integer.parseInt((String) comboBox_3.getSelectedItem()));
				 m.setSurveynum(id);
				try {
					if(Integer.valueOf((String) table.getValueAt(row, 3))>0)
					{
						if(daoo.mytablet1(m))
						{
							 d.setDrugid(Integer.valueOf((String) comboBox.getSelectedItem()));
							 d.setDrugname((String)comboBox_1.getSelectedItem());
							 d.setDrugtype((String)comboBox_2.getSelectedItem());
							 d.setDruginventory(a);
							 d.setShelvesnumber((String)comboBox_4.getSelectedItem());
							 d.setUnit(String.valueOf(comboBox_5.getSelectedItem()));
							 d.setSpecifications((String)comboBox_6.getSelectedItem());
							 d.setUnitprice(Integer.parseInt((String) comboBox_3.getSelectedItem()));
							try {
								
								if(dao.modify(d))
								{
									JOptionPane.showMessageDialog(null,"���ӳɹ���");
									
								}
								
							} catch (ClassNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							//���죬������ҩƷ��ͬʱ���޸�ҩƷ�Ŀ��¼���x������Ϊy���޸Ŀ��Ϊy-x
							//�������ʾҩƷ���ͺͿ������
						}
					}
					
					else {
						
							
							JOptionPane.showMessageDialog(null,"�Բ��𣡸�ҩƷ���ȱʧ������ϵ����Ա���ӡ�");
				
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(298, 488, 113, 27);
		contentPane.add(btnNewButton_1);
		
		
	}
}
