package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class cashierDao {
	PreparedStatement pstmt;
	Connection conn=new jdbc.JDBC().getconection();
	ResultSet rs;
	public boolean login(String cashierid,String cashierpass) throws ClassNotFoundException, SQLException {
		boolean flag =true;
		String sql="select *from ����Ա�˺� where ����Ա�˺� =? and ����Ա����=?";
		PreparedStatement ps= conn.prepareStatement(sql);
		ps.setString(1, cashierid);
		ps.setString(2, cashierpass);
		
		ResultSet rs= ps.executeQuery();
		if(rs.next()) {
			return flag;
		}else {
			flag=false;
		}
		return flag;
	}
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		cashierDao casdao =new cashierDao();
		casdao.login("111", "1112222");
//		patdao.login("533", "111");
		System.err.println("�ɹ�");
	}
}
