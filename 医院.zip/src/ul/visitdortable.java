package ul;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.doctor;
import bean.patient;
import bean.settleaccount;
import bean.visitdoctor;
import dao.doctorpass;
import dao.patientDao;
import dao.settleaccountdao;
import model.doctortable;
import model.visittablemodel;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class visitdortable extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	int row=0;
	/**
	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					visitdortable frame = new visitdortable();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public visitdortable(String num) throws SQLException {
		
		dispose();
		visittablemodel tablemodel;
		doctorpass ddao=new doctorpass();
		patientDao pdao=new patientDao();
		setBounds(100, 100, 601, 492);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 28, 583, 217);
		contentPane.add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("�����");
		lblNewLabel.setBounds(27, 258, 72, 18);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("��������");
		label.setBounds(27, 301, 72, 18);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("�����Ա�");
		label_1.setBounds(27, 341, 72, 18);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("��Ͻ��");
		label_2.setBounds(27, 381, 72, 18);
		contentPane.add(label_2);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(113, 255, 112, 24);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(113, 298, 112, 24);
		contentPane.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(113, 338, 112, 24);
		contentPane.add(comboBox_2);
		
		JLabel label_3 = new JLabel("ҽ��");
		label_3.setBounds(321, 258, 72, 18);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("����");
		label_4.setBounds(321, 301, 72, 18);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("��������");
		label_5.setBounds(321, 341, 72, 18);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("�Һŷ���");
		label_6.setBounds(321, 381, 72, 18);
		contentPane.add(label_6);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(419, 255, 112, 24);
		contentPane.add(comboBox_4);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setBounds(419, 298, 112, 24);
		contentPane.add(comboBox_5);
		
		JComboBox comboBox_6 = new JComboBox();
		comboBox_6.setBounds(419, 338, 112, 24);
		contentPane.add(comboBox_6);
		
		JComboBox comboBox_7 = new JComboBox();
		comboBox_7.setBounds(419, 378, 112, 24);
		contentPane.add(comboBox_7);
		
		textField = new JTextField();
		textField.setBounds(113, 378, 112, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		
		
		
		JButton btnNewButton_2 = new JButton("����");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					patientexcel pexcel;
					try {
						pexcel = new patientexcel(num);
						pexcel.setVisible(true);
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(418, 412, 113, 27);
		contentPane.add(btnNewButton_2);
		
		
		table = new JTable();
		ArrayList<doctor> patientlist=ddao.findlistdor(num);
		doctor d=patientlist.get(0);
		
		ArrayList list=pdao.listdoctor(d.getDorname());
		tablemodel=new visittablemodel(list);
		table.setModel(tablemodel);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				row=table.getSelectedRow();
				comboBox.addItem(String.valueOf(table.getValueAt(row, 0)));//
				comboBox_1.addItem(String.valueOf(table.getValueAt(row, 1)));//
				comboBox_2.addItem(String.valueOf(table.getValueAt(row, 2)));//
				comboBox_6.addItem(String.valueOf(table.getValueAt(row, 3)));//
				comboBox_4.addItem(String.valueOf(table.getValueAt(row, 4)));//
				comboBox_5.addItem(String.valueOf(table.getValueAt(row, 5)));//
//				textField.setText(String.valueOf(table.getValueAt(row, 6)));//
				comboBox_7.addItem(String.valueOf(table.getValueAt(row, 7)));//
				
			}
		});
		scrollPane.setViewportView(table);
		
		
		JButton btnNewButton = new JButton("����");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				visitdoctor v=new visitdoctor();
				v.setVistnum((String) comboBox.getSelectedItem());
				v.setResult(textField.getText());
				if(!textField.getText().equals(table.getValueAt(row, 6)))
				{
					
					if(pdao.modfiyinfo(v))
					{
						
						settleaccountdao stdao=new settleaccountdao();
						settleaccount d=new settleaccount();
						try {
							d.setSurverynum(String.valueOf(table.getValueAt(row, 0)));
							d.setName(String.valueOf(table.getValueAt(row, 1)));
							d.setSflag("δ����");
							if(stdao.addaccount(d)) {
								JOptionPane.showMessageDialog(null, "�Ѿ����Ӳ���");
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}else if(textField.getText().equals("�ȴ�����")||textField.getText().equals("")){
					JOptionPane.showMessageDialog(null, "�Բ����㻹û��д����Ͻ��");
				}
				else {
					JOptionPane.showMessageDialog(null, "�ò����Ѿ���ϣ������ظ�����");
				}
				
			}
			
		});
		btnNewButton.setBounds(14, 412, 113, 27);
		contentPane.add(btnNewButton);
		
		
		
		JButton btnNewButton_1 = new JButton("����ҩƷ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					if(table.getValueAt(row,6).equals("�ȴ�����")) {
						drugtable d=new drugtable(Integer.parseInt((String) comboBox.getSelectedItem()));
						d.setVisible(true);
					}
					else if(textField.getText().equals(""))
					{	
						JOptionPane.showMessageDialog(null, "�����Ӳ���");
					}
					else {
						JOptionPane.showMessageDialog(null, "�ò����Ѿ�����޷�������ҩƷ");
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "���ȡ���е�����");
				}
			}
		});
		btnNewButton_1.setBounds(224, 412, 113, 27);
		contentPane.add(btnNewButton_1);
		
		
		
		
	}
}
